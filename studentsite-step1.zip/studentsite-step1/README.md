# John Doe's Student Site

This is my student website for 2021 created for my NMA courses

[View my Site](https://johndoenma.github.io/studentsite/)
