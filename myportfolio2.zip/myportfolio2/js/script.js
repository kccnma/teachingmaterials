document.addEventListener("DOMContentLoaded", function() {
  //JS
});
