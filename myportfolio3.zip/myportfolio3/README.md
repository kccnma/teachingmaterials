# myportfolio2
This is a static portfolio test that I am doing only because Chris is asking me too. I reluctantly want to. I do not like git. Nor do I like Chris.

[View Demo](https://johndoenma.github.io/myportfolio2/)